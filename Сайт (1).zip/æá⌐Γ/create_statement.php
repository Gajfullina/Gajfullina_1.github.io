<?php
session_start();
require 'C:\OSPanel\domains\Damn\Сайт\db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: c:\OSPanel\domains\Damn\Сайт\login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $car_number = $_POST['car_number'];
    $description = $_POST['description'];
    $user_id = $_SESSION['user_id'];

    $stmt = $pdo->prepare("INSERT INTO statements (car_number, description, user_id, status) VALUES (?, ?, ?, 'новое')");
    if ($stmt->execute([$car_number, $description, $user_id])) {
        echo "Заявление успешно подано!";
    } else {
        echo "Ошибка подачи заявления.";
    }
}
?>

<form method="post">
    <input type="text" name="car_number" placeholder="Номер автомобиля" required>
    <textarea name="description" placeholder="Описание нарушения" required></textarea>
    <button type="submit">Подать заявление</button>
</form>