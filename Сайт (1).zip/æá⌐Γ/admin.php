<?php
session_start();
require 'C:\OSPanel\domains\Damn\Сайт\db.php';

if (!isset($_SESSION['admin'])) {
    // Проверка логина и пароля администратора
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if ($_POST['login'] === 'сorr' && $_POST['password'] === 'rpassword') {
            $_SESSION['admin'] = true;
        } else {
            echo "Неверный логин или пароль администратора.";
        }
    }
}

if (!isset($_SESSION['admin'])) {
?>
<form method="post">
    <input type="text" name="login" placeholder="Логин администратора" required>
    <input type="password" name="password" placeholder="Пароль администратора" required>
    <button type="submit">Войти в панель администратора</button>
</form>
<?php
} else {
    // Отображение всех заявлений
    $stmt = $pdo->query("SELECT * FROM statements");
    $statements = $stmt->fetchAll();
?>
<h1>Панель администратора</h1>
<table>
    <tr>
        <th>ФИО</th>
        <th>Описание нарушения</th>
        <th>Номер автомобиля</th>
        <th>Статус</th>
        <th>Действия</th>
    </tr>
    <?php foreach ($statements as $statement): ?>
        <tr>
            <td><?php echo htmlspecialchars($statement['user_id']); ?></td> <!-- Здесь нужно получить ФИО пользователя -->
            <td><?php echo htmlspecialchars($statement['description']); ?></td>
            <td><?php echo htmlspecialchars($statement['car_number']); ?></td>
            <td><?php echo htmlspecialchars($statement['status']); ?></td>
            <td>
                <form method="post">
                    <input type="hidden" name="statement_id" value="<?php echo $statement['id']; ?>">
                    <select name="status">
                        <option value="подтверждено">Подтверждено</option>
                        <option value="отклонено">Отклонено</option>
                    </select>
                    <button type="submit">Изменить статус</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<?php
}
?>