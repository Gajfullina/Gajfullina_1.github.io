<?php
session_start();
require 'C:\OSPanel\domains\Damn\Сайт\db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: c:\OSPanel\domains\Damn\Сайт\login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM statements WHERE user_id = ?");
$stmt->execute([$user_id]);
$statements = $stmt->fetchAll();
?>

<h1>Мои заявления</h1>
<table>
    <tr>
        <th>Описание нарушения</th>
        <th>Номер автомобиля</th>
        <th>Статус</th>
    </tr>
    <?php foreach ($statements as $statement): ?>
        <tr>
            <td><?php echo htmlspecialchars($statement['description']); ?></td>
            <td><?php echo htmlspecialchars($statement['car_number']); ?></td>
            <td><?php echo htmlspecialchars($statement['status']); ?></td>
        </tr>
    <?php endforeach; ?>
</table>

<a href="C:\OSPanel\domains\Damn\Сайт\create_statement.php">Создать новое заявление</a>